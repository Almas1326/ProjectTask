package com.beingjavaguys.domain;

public class Qr {

}
